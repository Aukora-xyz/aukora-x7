(this example is rendered by Alectryon in the CI)

```lean
{{#include phoas.lean}}
```
